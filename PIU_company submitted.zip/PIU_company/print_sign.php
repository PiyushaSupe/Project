<?php	
	require('dbconnect.php');
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Your service register details</title>
</head>
<body>
	<style type="text/css">
		#printing{
			border: 2px solid;
			padding: 100px 100px 100px 100px;
			margin: 100px 100px 100px 100px;

		}
	</style>
<section id="printing">

	<h1>Service registration details </h1>

	<table>
		<tr>
			
		</tr>
	</table>
	

</section>
	<?php 





	 ?>





</body>
</html>