<!DOCTYPE html>
<html>
<head>

	<?php 
	require('dbconnect.php');
	
	//include ('');
	//include ('');
	require_once('./php/component.php');
	require_once('./php/CreateDb.php');

	    //create instance of CreateDb class
	$database = new CreateDb("id19400399_productdb","tree");
//

	function listing($fname,$lname, $name, $id, $purpose, $city, $state, $number){

	$element = "
	<tr>
		<td>$id </td>
		<td>$fname </td>
		<td>$lname </td>
		<td>$name </td>
		<td>$purpose </td>
		<td>$city </td>
		<td>$state </td>
		<td>$number <td>
		
	</tr>
	";
	echo $element;

}


	 ?>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Trees for good (website made by Piyusha Supe)</title>


	<script type="text/javascript">
	// onclick      - used  - in logo
	// onmouseover	- used - rollover in about
	// onmouseout	- used - rollover in about
	// onmousedown	- used in para of quote
	// onmouseup	- used in para of quote
	// onmousemove  - used with onmouseout in logo quote
	// onfocus	    - used in input fname lname
	// onsubmit	    - used in form	+++++++++++
	// onchange    
	//onselect      - used - fname field
	//ondblclick    - used - in search button
	//onload        - used when body is loaded
	//onunload
	//onresize
	// onkeydown 
	// onkeyup
	//onreset
	//onkeypress
	// onunload	
	// onresize
	// onblur
	
	function submitme(){ //ondblclick
		alert("SORRY :( SEARCH BUTTON NOT ACTIVATED YET");
	}

	function selecting(){ //onselect
		document.getElementById('demo1').innerHTML = "<b>You selected some text </b>";
	}

	function mouseupdown(elmnt, clr){
		elmnt.style.color = clr;
	}

	function mousemoving(){
		document.getElementById('demo2').innerHTML = "The true meaning of life is to plant trees, under whose shade you do not expect to sit";
	}
	function mousingout(){
		document.getElementById('demo2').innerHTML = " ";
	}

	function loadme(){
		alert("Welcome to trees for good by Piyusha, Wish to make a change! :)")
	}

	function byebye(){
		alert("Thank you for visiting TREES FOR GOOD :)")
	}

	function focusingon(x){
		x.style.background = "lightskyblue";
	}
	
	function alertingform(){
		alert('Do you really want to submit?')
	}
		
	</script>

	
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

		<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

	<style type="text/css">
		.container-fluid{
			background: black;
			color: white;
		}
		#ordername{
			font-size: 40px;
			font-family: lucida;
			font-style: italic;
		}
		#formorder{
			padding: 20px 20px 20px 20px;
			align-content: center;
		}
		#about{
			padding-right: 50px;
		}
		th{
			background-color: lightskyblue;
			color: black;
		}
	</style>

	
</head>
<body  onload="loadme()">

<div class="container-fluid" >
	<!-- <section>
		<div class="row">
			<div class="col-md-12" id="mainflex">
				
			<h1 style="font-family: lucida; font-size: 60px;"><i>Trees for good</i></h1>
				
			</div>
			<br><br><br><br>
		</div>
	</section> -->
<section >
			
			<div class="row" >
				<div class="col-md-12">
					
							<nav class="navbar navbar-expand-lg navbar-dark bg-dark" >
							  <a class="navbar-brand" href="#"></a>
							  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
							    <span class="navbar-toggler-icon"></span>
							  </button>
							  <a class="navbar-brand">
							  	<img src="logo.jpg" width="150px" height="50px" alt="logo" onclick="window.open('treesforgood.html#treeavail')" onmousemove="mousemoving()" onmouseout="mousingout()">
							  </a>

							  <div class="collapse navbar-collapse" id="navbarSupportedContent" >
							    <ul class="navbar-nav mr-auto">


							      <li class="nav-item active">
							        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
							      </li>
							      <li class="nav-item">
							        <a class="nav-link" href="#about">About</a>
							      </li>
							      <li class="nav-item">
							        <a class="nav-link" href="#order">Order</a>
							      </li>
							      <li class="nav-item">
							        <a class="nav-link" href="index_piu_company.php">Go to PIUC website</a>
							      </li>
							      <li class="nav-item">
							        <a class="nav-link" href="#customers">List of happy customers</a>
							      </li>
							    </ul>
							    <form class="form-inline my-2 my-lg-0">
							      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
							      <button class="btn btn-outline-success my-2 my-sm-0" type="submit" ondblclick="submitme()">Search</button>
							    </form>
							  </div>
							</nav>
				</div> <!-- eof column -->
			</div> <!-- eof row navbar -->
		</section><!-- eof section row2 navbar -->

		<section>
			<div class="row">
				<div class="col-md-12">
					<p id="demo2" style="font-size: 25px; font-family: georgia; text-align: center;"></p>
				</div>
			</div>
		</section>



	<section>
			<div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
			  <ol class="carousel-indicators">
			    <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
			    <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
			    <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
			  </ol>
			  <div class="carousel-inner">
			    <div class="carousel-item active" >
			      <img src="img_woods5.jpg" class="d-block w-100" alt="...">
			      <div class="carousel-caption d-none d-md-block">
			        <h1>Peace</h1>
			        <p>The soul that's tired from the city lights craves for peace</p>
			      </div>
			    </div>
			    <div class="carousel-item">
			      <img src="img_woods2.jpg" class="d-block w-100" alt="...">
			      <div class="carousel-caption d-none d-md-block">
			        <h1>Serenity</h1>
			        <p>If serenity was to be pictorially depicted will it look like this?</p>
			      </div>
			    </div>
			    <div class="carousel-item">
			      <img src="img_woods3.jpg" class="d-block w-100" alt="...">
			      <div class="carousel-caption d-none d-md-block">
			        <h1>Happiness</h1>
			        <p>Happiness comes from believing... will you believe in yourself?</p>
			      </div>
			    </div>
			  </div>
			  <button class="carousel-control-prev" type="button" data-target="#carouselExampleCaptions" data-slide="prev">
			   <span class="carousel-control-prev-icon" aria-hidden="true"></span>
			    <span class="sr-only">Previous</span>
			  </button>
			  <button class="carousel-control-next" type="button" data-target="#carouselExampleCaptions" data-slide="next">
			   <span class="carousel-control-next-icon" aria-hidden="true"></span>
			    <span class="sr-only">Next</span>
			  </button>
			</div>

	</section>   <!-- eof section of carousel -->
<form onsubmit="alertingform()" action="treedata.php" method="post">
<section id="formorder">
	<section>
		<div class="row">
			<p id="mousemovingquote" style="font-size: 30px; font-style: italic; font-family: Lucida; " onmousedown="mouseupdown(this, 'turquoise')" onmouseup="mouseupdown(this, 'lightpink')">
				The best time to plant a tree was 20 years ago, The second best time is now!!
			</p>

			<marquee id="ordername">Order Plants  </marquee>
			<p style="padding-left: 20px; font-size: 50px; font-style: italic; text-align: center;"> Order Form </p>

			<p style="padding-left: 20px; font-size: 20px; font-style: italic;">Fill the below form and proceed for payment you will receive the order in approximately 20 days depending upon the shipping distance</p>
            
            
			<div class="col-md-6" id="order">	
			<p id="ordername" style="font-size: 30px; text-decoration: underline;"> Your information </p>			
				
					 <div class="form-group">
					  <label for="fname">FIRST NAME:</label>
					  <input required name = "fname"  type="text" class="form-control" id="fname" value="Ashley" onselect="selecting()" onfocus="focusingon(this)" onkeyup="this.value = this.value.toUpperCase();">
					  <p id="demo1"> </p>
					 </div>

					  <div class="form-group">
					  <label for="lname">LAST NAME:</label>
					  <input required name="lname" type="text" class="form-control" id="lname" onfocus="focusingon(this)" onkeyup="this.value = this.value.toUpperCase();">
					 </div>

					  <div class="form-group">
					    <label for="exampleInputEmail1">Email address</label>
					    <input required name="mail" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" onfocus="focusingon(this)">
					  </div>


					 <div class="form-group">
					  <label for="formControlRange">Prioritize how early do you want it to be shipped:</label>
					  <input type="range" class="form-control" id="formControlRange" onfocus="focusingon(this)">
					 </div>

					 <div class="form-group">
				    <label for="">Address</label>
				    <input required name="address1" type="text" class="form-control" id="" placeholder="1234 Main St" onfocus="focusingon(this)" >
				  </div>
				  <div class="form-group">
				    <label for="2">Address 2</label>
				    <input required name="address2" type="text" class="form-control" id="2" placeholder="Apartment, studio, or floor" onfocus="focusingon(this)">
				  </div>
				  <div class="form-row">
				    <div class="form-group col-md-6">
				      <label for="inputCity">City</label>
				      <input required name="city" type="text" class="form-control" id="inputCity" onfocus="focusingon(this)" onkeyup="this.value = this.value.toUpperCase();">
				    </div>
				    <div class="form-group col-md-4">
				      <label for="inputState">State</label>
				      <select required name="state" class="custom-select" id="validationDefault04" required>
				        <option selected disabled value="">Choose...</option>


								<option value="Andhra Pradesh">Andhra Pradesh</option>
								<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
								<option value="Arunachal Pradesh">Arunachal Pradesh</option>
								<option value="Assam">Assam</option>
								<option value="Bihar">Bihar</option>
								<option value="Chandigarh">Chandigarh</option>
								<option value="Chhattisgarh">Chhattisgarh</option>
								<option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
								<option value="Daman and Diu">Daman and Diu</option>
								<option value="Delhi">Delhi</option>
								<option value="Lakshadweep">Lakshadweep</option>
								<option value="Puducherry">Puducherry</option>
								<option value="Goa">Goa</option>
								<option value="Gujarat">Gujarat</option>
								<option value="Haryana">Haryana</option>
								<option value="Himachal Pradesh">Himachal Pradesh</option>
								<option value="Jammu and Kashmir">Jammu and Kashmir</option>
								<option value="Jharkhand">Jharkhand</option>
								<option value="Karnataka">Karnataka</option>
								<option value="Kerala">Kerala</option>
								<option value="Madhya Pradesh">Madhya Pradesh</option>
								<option value="Maharashtra">Maharashtra</option>
								<option value="Manipur">Manipur</option>
								<option value="Meghalaya">Meghalaya</option>
								<option value="Mizoram">Mizoram</option>
								<option value="Nagaland">Nagaland</option>
								<option value="Odisha">Odisha</option>
								<option value="Punjab">Punjab</option>
								<option value="Rajasthan">Rajasthan</option>
								<option value="Sikkim">Sikkim</option>
								<option value="Tamil Nadu">Tamil Nadu</option>
								<option value="Telangana">Telangana</option>
								<option value="Tripura">Tripura</option>
								<option value="Uttar Pradesh">Uttar Pradesh</option>
								<option value="Uttarakhand">Uttarakhand</option>
								<option value="West Bengal">West Bengal</option>


				      </select>
				    </div>
				    <div class="form-group col-md-2">
				      <label for="inputZip">Zip</label>
				      <input required name = "zip" type="text" class="form-control" id="inputZip">
				    </div>
				  </div>
				  
					
				<div class="form-group">
				      <label for="inputState">Tree Location:</label>
				      <select class="custom-select" id="validationDefault04" required>
				        <option selected disabled value="">Choose...</option>


								<option value="Andhra Pradesh">Andhra Pradesh</option>
								<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
								<option value="Arunachal Pradesh">Arunachal Pradesh</option>
								<option value="Assam">Assam</option>
								<option value="Bihar">Bihar</option>
								<option value="Chandigarh">Chandigarh</option>
								<option value="Chhattisgarh">Chhattisgarh</option>
								<option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
								<option value="Daman and Diu">Daman and Diu</option>
								<option value="Delhi">Delhi</option>
								<option value="Lakshadweep">Lakshadweep</option>
								<option value="Puducherry">Puducherry</option>
								<option value="Goa">Goa</option>
								<option value="Gujarat">Gujarat</option>
								<option value="Haryana">Haryana</option>
								<option value="Himachal Pradesh">Himachal Pradesh</option>
								<option value="Jammu and Kashmir">Jammu and Kashmir</option>
								<option value="Jharkhand">Jharkhand</option>
								<option value="Karnataka">Karnataka</option>
								<option value="Kerala">Kerala</option>
								<option value="Madhya Pradesh">Madhya Pradesh</option>
								<option value="Maharashtra">Maharashtra</option>
								<option value="Manipur">Manipur</option>
								<option value="Meghalaya">Meghalaya</option>
								<option value="Mizoram">Mizoram</option>
								<option value="Nagaland">Nagaland</option>
								<option value="Odisha">Odisha</option>
								<option value="Punjab">Punjab</option>
								<option value="Rajasthan">Rajasthan</option>
								<option value="Sikkim">Sikkim</option>
								<option value="Tamil Nadu">Tamil Nadu</option>
								<option value="Telangana">Telangana</option>
								<option value="Tripura">Tripura</option>
								<option value="Uttar Pradesh">Uttar Pradesh</option>
								<option value="Uttarakhand">Uttarakhand</option>
								<option value="West Bengal">West Bengal</option>

				      </select>
				    </div>	


				
				
			</div>

			<div class="col-md-6" id="order">
				<p id="ordername" style="font-size: 30px; text-decoration: underline;"> Plant Information </p>

				    <div class="form-group">
				    	<label for="numoftree"> Number of trees:</label>
				    	<input required name="number" type="number" name="numoftree">			    	
				    </div>

				   <div class="form-group">
				    <label for="personorg">To whom do you want to dedicate this tree?</label>
				    <input required name="name" type="text" class="form-control" id="personorg" placeholder="Mr. Atkinson" onkeyup="this.value = this.value.toUpperCase();">
				  </div>

				  <div class="form-group">
				    <label for="purpose">Purpose of the trees:</label>
				    <input required name="purpose" type="text" class="form-control" id="purpose" placeholder="">
				  </div>


				  <label class="form-check-label" for="form-check">
					    <u>Select the tree types: </u><bR>
					  </label>
				  <div class="form-check">
					  <input  class="form-check-input" type="checkbox" value="" id="checkvalue1">
					  <label class="form-check-label" for="checkvalue1">
					    Eucalyptus (E. torelliana spp.)
					  </label>
					  <br>


					  <input class="form-check-input" type="checkbox" value="" id="checkvalue2">
					  <label class="form-check-label" for="checkvalue2">
					    Mahogany (Swietenia macrophylia spp.)
					  </label>
					  <br>

					  <input class="form-check-input" type="checkbox" value="" id="checkvalue3">
					  <label class="form-check-label" for="checkvalue3">
					    Mahogany (Shorea roxburghii spp.)
					  </label>
					  <br>

					  <input class="form-check-input" type="checkbox" value="" id="checkvalue4">
					  <label class="form-check-label" for="checkvalue4">
					    Opepe (Nauclea spp.)
					  </label>
					  <br>

					  <input class="form-check-input" type="checkbox" value="" id="checkvalue5">
					  <label class="form-check-label" for="checkvalue5">
					    Black Afara (Terminalia ivorensis)
					  </label>
					  <br>

					  <input class="form-check-input" type="checkbox" value="" id="checkvalue6">
					  <label class="form-check-label" for="checkvalue6">
					   White Afara (Terminalia superba)
					  </label>
					  <br>

					  <input class="form-check-input" type="checkbox" value="" id="checkvalue7">
					  <label class="form-check-label" for="checkvalue7">
					    Teak (Gedu) (Tectona grandis)
					  </label>
					  <br>

					  <input class="form-check-input" type="checkbox" value="" id="checkvalue8">
					  <label class="form-check-label" for="checkvalue8">
					    Gmelina (Gmelina arborea)
					  </label>
					  <br>


					</div>

				 <br><span style="font-size:15px;">IMPORTANT:    The subtotal and total amount is the donation amount that should be above 501 &#8377; rupees and can be altered as you wish over this amount (It will be donation to this purpose). As &#8377; 501 is minimal amount just for shipping of trees </span><br><br> <label for="subtotal">SUBTOTAL:</label><br>

				  <div class="input-group mb-3">
				  	
					  <div class="input-group-prepend">
					    <span class="input-group-text">&#8377;</span>
					  </div>
					  <input required name="subtotal" type="text" class="form-control" aria-label="Amount (to the nearest dollar)">
					  <div class="input-group-append">
					    <span class="input-group-text">.00</span>
					  </div>
					</div>


					<label for="total">TOTAL:</label><br>
					<div class="input-group mb-3">
						
					  <div class="input-group-prepend">
					    <span class="input-group-text">&#8377;</span>
					  </div>
					  <input  required name="total" type="text" class="form-control" aria-label="Amount (to the nearest dollar)">
					  <div class="input-group-append">
					    <span class="input-group-text">.00</span>
					  </div>
					</div>
			</div>
			
		</div>
	</section>
</section>

	<section>	
		<div class="row">
			<div class="col-md-12">
				<!-- <form > -->
				<div class="form-group">
				    <div class="form-check">
				    	<br><br><br>
				      <input required class="form-check-input" type="checkbox" id="gridCheck">
				      <label class="form-check-label" for="gridCheck">
				        I agree with all the terms mentioned above and on cancellation of order refund is not supported 
				      </label>
				    </div>
				  </div>		
				 <!--  <button type="submit" class="btn btn-primary" >Submit</button> -->
				 <input type="submit" name="submit" class="btn btn-success" value="SUBMIT" style="font-size:25px;text-align: center;width: 150px;" id="res" onsubmit="alertingform()">
				 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
				 <input type="reset" name="reset" class = "btn btn-warning" value="RESET" style="font-size:25px; text-align: center; width: 150px;" id="sub">
				<!-- </form> -->
			</div>
		</div>
	</section>
</form>

	<section>
		<div class="row">
			<div class="col-md-12" id="about">
				<hr>
				<p style="padding-left: 20px; font-size: 50px; font-style: italic; text-align: center;"> 
					<img src="img_woods7.jpg" width="700px" height="400px" onmouseover = "src = 'img_woods4.jpg'" onmouseout = "src='img_woods7.jpg'">
					<p style="padding-left: 20px; font-size: 50px; font-style: italic; text-align: center;">About us</p>
				</p>

						<p style="padding-left: 20px; font-size: 20px; font-style: italic; text-align: justify;">					
						T.R.E.E Project came out of the urge to assist in creating a specific, productive and sustainable action strategy towards afforestation of the extensively depleted vegetation and forest cover of communities within the most exposed regions.
						<br><br>
						Our observations led to biodiversity concerns. It was observed that the rate at which trees were being lumbered indiscriminately on a daily basis by locals and timber merchants, particularly to produce charcoal and furniture, there will be a serious distortion in the ecosystem and ecology of these exposed communities which may eventually end as an inexplicable environmental disaster.
						<br><br>
						These deforestation activities portend danger and needs to be countered with control strategies before it gets worse. It is on record that, almost 20% of global carbon emissions are caused by deforestation. It is also becoming obvious that there is already a disruption in the water cycle around this region of Africa.
						<br><br>
						This afforestation project, the coordinated planting and management of trees and the advocacy strategies to be deployed to curb and minimize the deliberate felling of trees for both domestic and export purposes will reduce global warming.
						<br><br>
						T.R.E.E Project strategy is to continuously encourage the replenishing of depleted woodland across communities by planting selected indigenous and adopted trees to protect these vulnerable communities from the immediate and future consequences of deforestation.
						<br><br>
						It is a painstaking strategy to salvage these communities from the dare environmental and even economic consequences of deforestation using the planting and management of trees as well as the expansion of forest resources by creating more woodland.
						<br><br>
						Similar related initiatives are being undertaken in other climes and one of such is the New York Restoration Project which was conceived by the Mayor, Michael Bloomberg.
						<br><br>
						The New York Restoration Project was designed to oversee the planting of One Million Trees across the New York City landscape over a 10 year period (2007-2017). The project was tagged “MillionTreesNYC”.
						<br><br>
						While the New York Restoration Project intends to restore the aesthetic façade of the city, T.R.E.E. Project intends to restore, replenish and replicate the planting and management of selected indigenous and adopted trees that can mitigate deforestation over the next 25 years and more.
						<br><br>
						It is a good strategy of engaging youths, particularly school age kids, youth volunteers and women farmers across communities. It is a deliberate attempt to give them the opportunity to adopt afforestation as a culture and lifestyle.
						<br><br>
						T.R.E.E. Project will continuously make available tree seedlings with adequate training of interested volunteers irrespective of age or status under the “Special Community Understanding” platform.
						<br><br>
						T.R.E.E. Project will support and supervise in the aspects of layout design, seed selection, planting, grooming and management for sustainability in communities with depleted woodland area.

						The overall goal is a win-win situation for all; the climate, the environment and the people.
						</p>
						<p style="padding-left: 20px; font-size: 20px; font-style: italic; white-space: pre;" id="treeavail">
T.R.E.E. Project selected indigenous and 
adopted tree species include:

1.Eucalyptus (E. torelliana spp.)

2.Mahogany (Swietenia macrophylia spp.)

3.Mahogany (Shorea roxburghii spp.)

4.Opepe (Nauclea spp.)

5.Black Afara (Terminalia ivorensis)

6.White Afara (Terminalia superba)

7.Teak (Gedu) (Tectona grandis)

8.Gmelina (Gmelina arborea)

					</p>			
			</div>
			
		</div>
	</section>

	<section>
		<div class="row">
			<div class="col-md-12">

				<style type="text/css">
									.glowing{
						    		/*text-shadow:
						  0 0 10px #fff700, 0 0 20px #fff700,
						  0 0 30px #fff700, 0 0 50px #fff700;*/

						  text-shadow:
						  0 0 10px yellow, 0 0 20px black,
						  0 0 30px black, 0 0 30px black;

						  font-style: italic;
						  font-family: lucida;
						  font-size: 40px;
						  font-weight: bolder;
						  background-color: ;
						  color:;


						    	}
				</style>
				<span id = "customers"class="glowing" style="color:lightgoldenrodyellow;">List of people who tried to save a bit of nature and planted trees through us:</span>

<br> <br>
	<table border="2px solid white" id="tableproviders" class="table table-hover table-dark">
		<tr>
			<th>Sr. no.</th>
			<th>First name</th>
			<th>Last name</th>
			<th>Dedicated to</th>
			<th>On the ocasion of</th>
			<th>City</th>
			<th>State</th>
			<th>Number of saplings</th>
		</tr>
      <?php
			$result = $database->getData();
			while($row = mysqli_fetch_assoc($result)){
				listing($row['fname'],$row['lname'],$row['name'], $row['id'], $row['purpose'], $row['city'], $row['state'], $row['number']);
			}
			//div_space();
		
		?>
	</table>	<br> <br><br>			
			</div>
		</div>
	</section>



<footer  align = "center" style="background: darkgoldenrod; padding: 20px 20px 20px 20px;">
     <br>&#169; Copyright  Piyusha  Supe 2022 
     <br>
     <br>We are affilaited to the good cause of the PIUC project.<br>This is a site made by a learner (as a practice) all other due credits to respective owners 
</footer>

</div>  <!--  eof container fluid -->
</body>
</html>

	
				