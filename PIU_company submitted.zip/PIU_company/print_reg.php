<title>Your service register details</title>
<?php include('element.php'); ?>
<?php 
		include 'heading.php';
		div_space();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	

	<!-- font awesome links -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" >
	<link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css">

			<!--bootstrap css links -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
			<!-- bootstrap js links -->
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

    <style type="text/css">
    	
    	.glowing{
		    		text-shadow:
		  0 0 5px #fff700, 0 0 10px #fff700,
		  0 0 20px #fff700, 0 0 40px #fff700;
		  font-style: italic;
		  font-family: lucida;
		  font-size: 50px;
		  font-weight: bolder;
		  /*background-color: black;
		  color: white;*/

		    	}

		.regform{
			background: url('https://images.pexels.com/photos/268415/pexels-photo-268415.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1');
			margin: 30px 30px 30px 30px;
			padding: 30px 30px 30px 30px;
		}
		#regformdiv {
			margin: 30px 30px 30px 30px;
			padding: 20px 50px 20px 50px;
			background: white;
			font-weight: bold;
			font-size: 20px;

		}
		input{
			font-size: 20px;
		}

		#toprint{
			border: 3px solid lightgray;
			margin: 30px 30px 30px 30px;
			padding: 20px 50px 20px 50px;
		}

    </style>
</head>
<body>
<section class="regform">
	<section class="form" id="regformdiv">
			<center>
			<h1 class="glowing">Printing details of a registered service</h1>
			</center>
			<div class="row">
				<div class="col-md-12">

	<form method="post" action="print_service.php">


			  <div class="form-group">
			    <label for="name">Name</label>
			    <input type="text" class="form-control" id="name"  placeholder="Please enter the name you entered while registering" name="name" required>
			    <small id="describe" class="form-text text-muted">Enter the name entered while registering.</small>
			  </div>
			  <div class="form-group">
			    <label for="email">Email</label>
			    <input type="text" class="form-control" id="email"  placeholder="email" name="mail" required>
			    <small id="describe" class="form-text text-muted">Enter the email entered while registering.</small>
			  </div>
			  <div class="form-group">
			    <label for="company">Company Name</label>
			    <input type="text" class="form-control" id="company" placeholder="Company name" name="company" required>
			    <small id="describe" class="form-text text-muted">Enter the company name that you entered while registering</small>
			  </div>
			  <div class="form-group">
			    <label for="service">Service</label>
			    <input type="text" class="form-control" id="service" placeholder="Service name" name="service"  required>
			    <small id="describe" class="form-text text-muted">Enter the service name</small>
			  </div>
			  <div class="form-check">
			    <input type="checkbox" class="form-check-input" id="check" required>
			    <label class="form-check-label" for="check">Check me out</label>
			  </div><br> <br>
			  <button type="submit" style = "width: 200px;" class="btn btn-warning" name="print"><large><b>Submit & Print</b></large></button>
		
	</form>
		</div>
	</div>
</section>
</section>
</section>
</body>
</html>


<?php include 'footing.php'; ?>