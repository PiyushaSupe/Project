<?php
	$server = "localhost";
	$user = "root";
	$pwd = "";
	$dbase = "productdb";

	$conn = mysqli_connect($server,$user,$pwd,$dbase);

	/*$conn = mysqli_connect('localhost','root','','web-interns');*/

	/*
	if($conn->connect_error)
	{
		die('connection failed :'.$conn->connect_error);
	}
	else
		echo " connection successfull";*/


?>