<?php

	function component($productname, $productprice, $productimg, $productid,$desc,$company)
	{
		$element = 
		"<div class=\"col-md-3 col-sm-6 my-3 my-md-0\">
			<form action=\"index.php\" method=\"post\">
				<div class=\"card shadow  p-3 mb-5 bg-white rounded\">
					<div>
						<img src=\"$productimg\" alt=\"image1\" class=\"img-fluid card-img-top\">
					</div>
					<div class=\"card-body\">
						<h5 class=\"card-title\">$productname</h5>
						<h6>
							<i class=\"fas fa-star\"></i>
							<i class=\"fas fa-star\"></i>
							<i class=\"fas fa-star\"></i>
							<i class=\"fas fa-star\"></i>
							<i class=\"far fa-star\"></i>
						</h6>	
						<p class=\"card-text\">
						<br>Company offering the service:<h6>$company</h6> <br>
						$desc
							Receive the best and quality assured services at your doorstep!
						</p>
						<h5>
							<small><s class=\"text-secondary\">&#8377;5000</s></small>
							<span class=\"price\">&#8377;$productprice</span>
						</h5>
						<button class= \"btn btn-warning my-3\" type=\"submit\" name=\"add\">Avail Service<i class=\"fas fa-shopping-cart\"></i></button>

						<input type='hidden' name='product_id' value='$productid'>
					</div>
				</div>
			</form>
		</div>";

		echo $element;
	}



function cartElement($productimg, $productname, $productprice, $productid){
	$element = "
			<form action=\"cart.php?action=remove&id=$productid\" method=\"post\" class=\"cart-items\"> 
					<div class=\"border rounded\">
						<div class=\"row bg-white\">
							<div class=\"col-md-3 pl-0\">
								<img src=$productimg alt=\"image1\" class=\"img-fluid\">
							</div>
							<div class=\"col-md-6\">
								<h5 class=\"pt-2\">$productname</h5>
								<small class=\"text-secondary\">Seller: Phenomenal Infrastructure Utility company</small>
								<h5 class=\"pt-2\">&#8377;$productprice</h5>
								<button type=\"submit\" class=\"btn btn-warning\">Save for later</button>

								<button type=\"submit\" class=\"btn btn-danger mx-2\" name=\"remove\">Remove</button>
							</div>
							<div class=\"col-md-3 py-5\">
								<button type=\"button\" class=\"btn bg-light border rounded-circle\"><i class=\"fas fa-minus\"></i></button>

								<input type=\"text\"  value =\"1\" name=\"\" style=\"width: 40px;\" class=\"form-control  d-inline\">

								<button type=\"button\" class=\"btn bg-light border rounded-circle\"><i class=\"fas fa-plus\"></i></button>
							</div>
						</div>
						
					</div>
				</form>
	";
echo $element;

}

function homepgelement($productname, $productprice, $productimg, $productid,$desc,$company)
{
	$element="

	<div class=\"col-md-3 col-sm-6 my-3 my-md-0\">
			<form action=\"index.php\" method=\"post\">
				<div class=\"card shadow\">
					<div>
						<img src=\"$productimg\" alt=\"image1\" class=\"img-fluid card-img-top\">
					</div>
					<div class=\"card-body\">
						<h5 class=\"card-title\">$productname</h5>
						<h6>
							<i class=\"fas fa-star\"></i>
							<i class=\"fas fa-star\"></i>
							<i class=\"fas fa-star\"></i>
							<i class=\"fas fa-star\"></i>
							<i class=\"far fa-star\"></i>
						</h6>	
						<p class=\"card-text\">
						<br>Company offering the service:<h6>$company</h6> <br>
						$desc
							Receive the best and quality assured services at your doorstep!
						</p>
						<h5>
							 <small><s class=\"text-secondary\"></s></small>
							<span class=\"price\">&#8377;$productprice</span>
						</h5>
						

						<input type='hidden' name='product_id' value='$productid'>
					</div>
				</div>
			</form>
		</div>



	";
	echo $element;
}

function provider($person,$contact, $mail, $pid){

	$element = "
	<tr>
		<td>$pid </td>
		<td>$person </td>
		<td>$contact </td>
		<td>$mail </td>
		
	</tr>
	";
	echo $element;

}

?>
