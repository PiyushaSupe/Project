<?php

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Piu company</title>

	<style type="text/css">
		*{
			scroll-behavior: smooth;

		}
		
	</style>

	<!-- font awesome links -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" >
	<link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css">

			<!--bootstrap css links -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
			<!-- bootstrap js links -->
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
</head>
<body>

	<div class="container-fluid">
		<section>
		<div class="row">
			<header>
				
			</header>
		</div>
	    </section>

	    <!-- <section>
		<div class="row">
			<div class="col-md-12"></div>
		</div>
	    </section> -->
		<section>
			<header>
		<div class="row">
			<!-- <div class="col-md-12"> -->

			<!-- navbar for my website -->
			<nav class="navbar navbar-expand-lg navbar-dark bg-dark navbar-fixed-top" style="width:100%;position: fixed; left: 0; z-index: 100;">
				  <img id ="logo" src="piuclogo.jpg" class="navbar-brand" width="180px" height="70px">
				  <h2><a class="navbar-brand" href="#"><!-- Navbar --></a></h2>
				  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				    <span class="navbar-toggler-icon"></span>
				  </button>

				  <h6><div class="collapse navbar-collapse" id="navbarSupportedContent">
				    <ul class="navbar-nav mr-auto">
				      <li class="nav-item active">
				        <a class="nav-link" href="index_piu_company.php" target="_self">Home <span class="sr-only">(current)</span></a>
				      </li>
				      <li class="nav-item active">
				        <a class="nav-link" href="about.php" target="_self">About</a>
				      </li>

						<script>
						    $(document).ready(function () {
						        $('.dropdown-toggle').dropdown();
						    });
						</script>
				      <li class="nav-item dropdown active">
				        <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
				          Explore
				        </a>
				        <div class="dropdown-menu" >
				          <a class="dropdown-item" href="https://piyushasupe.blogspot.com/">Blogs</a>
				          
				          <div class="dropdown-divider"></div>
				          <a class="dropdown-item" href="list_of_providers.php">LIST OF SERVICE PROVIDERS</a>
				          
				        </div>
				      </li>

				      <li class="nav-item">
				        <a href="https://piyushasupe.blogspot.com/" class="nav-link active">Blogs</a>
				      </li>
				      <script>
						    $(document).ready(function () {
						        $('.dropdown-toggle').dropdown();
						    });
						</script>
				      <li class="nav-item dropdown active">
				        <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
				          Services
				        </a>
				        <div class="dropdown-menu" >
				          <a class="dropdown-item" href="shiprate.php">Shipping rates</a>
				          <a class="dropdown-item" href="privacy.php">Privacy policy</a>
				          <div class="dropdown-divider"></div>
				          <a class="dropdown-item" href="regproduct.php" target="_self">Register a new service!</a>
				          <a class="dropdown-item" href="signupform.php">Register as a new user/client</a>
				          <a class="dropdown-item" href="print_reg.php">Print your service details (for service providers only)</a>
				          <a class="dropdown-item" href="loginpage.php">Login to your account</a>
				        </div>
				      </li>
				    </ul>

				    <!-- <div class="btn-group">
					  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
					    Explore
					  </button>
					  <div class="dropdown-menu" data-bs-toggle="dropdown" >
					    <a class="dropdown-item" href="#">Blogs</a>
					    <a class="dropdown-item" href="#">Interior decor videos</a>
					    <a class="dropdown-item" href="#">House hunting videos</a>
					    <div class="dropdown-divider"></div>
					    <a class="dropdown-item" href="#">Go Healthy!</a>
					    <a class="dropdown-item" href="#">DIY laptop maintainance</a>
					  </div>
					</div> -->

				    <form class="form-inline my-2 my-lg-0">
				      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" style="width: 100px;">
				      <button class="btn btn-outline-info my-2 my-sm-0" type="submit">Search </button>
				    </form>
				    &nbsp; &nbsp;&nbsp;&nbsp; 
				    
				    <button class="btn btn-warning my-2 my-sm-0" type="login" onclick="window.open('loginpage.php')"><h6>Login</h6> </button>&nbsp; 
				    <button class="btn btn-success my-2 my-sm-0" type="signup" onclick="window.open('signupform.php')"><h6>Sign up</h6> </button>&nbsp;
				    <button class="btn btn-primary my-2 my-sm-0" type="regproduct" onclick="window.open('regproduct.php')" ><h6>Register a new service</h6> </button>


				  </div></h6>
			</nav>

			<!-- </div> --> <!-- eof col-md-12 -->
		</div><!-- eof row in container fluid -->
	</header>
	</section> <!-- eof section containing row navbar -->
<br> <br> <br> 

	
	</div> <!-- eof container fluid -->

</body>
</html>


