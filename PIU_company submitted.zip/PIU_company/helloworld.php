<?php  

echo "hello world";
 ?>