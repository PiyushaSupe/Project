<?php
	
	require('dbconnect.php');

	$name = $_POST['nameofservice'];
	$price = $_POST['priceofservice'];
	$imaging = $_POST['image'];
	$comp = $_POST['servicecompany'];
	$desc = $_POST['descofservice'];


	$person = $_POST['person'];
	$mail= $_POST['mail'];
	$contact = $_POST['contact'];
	

	
	$sql1 = "Insert into producttb(product_name,product_price, product_image,description, companyname)values('$name','$price','$imaging','$desc','$comp');"; 

	//$sql2 = "Insert into services(nameofproduct,price, imageofproduct,description, companyname)values('$name','$price','$imaging','$desc','$comp');";
	$sql3 = "Insert into reg_person(name, contact, mail)values('$person','$contact','$mail')";

	$run1=mysqli_query($conn,$sql1 );
	//$run2=mysqli_query($conn,$sql2 );
	$run3=mysqli_query($conn,$sql3 );

	echo "<script>alert('The service you provided is registered succesfully!!! THANK YOU for registering new servive');</script>";

             // echo "<script>window.location = 'index_piu_company.php'</script>";

	//echo " data inserted";
	// Redirect browser
	header("Location: index_piu_company.php");
	 
	 exit;



?>