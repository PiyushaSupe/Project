<title>Sign up for availing piu company services</title>
<?php 
		require_once('./php/component.php');
	    require_once('./php/CreateDb.php');

	    //create instance of CreateDb class
	//$database = new CreateDb("Productdb","userdata");


?>

<?php include('element.php'); ?>
<?php 
		include 'heading.php';
		//div_space();
?>
<script type="text/javascript">
	let password = document.getElementByID('password');
	let confirmpassword = document.getElementByID('confirmpassword');
	function checkpass(password, confirmpassword) {
		// body...
		if(password != confirmpassword){
			alert('Password and confirmed password must be the same! Try again! :(');

		}
	}
</script>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- font awesome links -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" >
	<link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css">

			<!--bootstrap css links -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
			<!-- bootstrap js links -->
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
	
</head>
<body>
	<style type="text/css">
		.regform{
			background: url('https://images.pexels.com/photos/326333/pexels-photo-326333.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1');
			margin: 30px 30px 30px 30px;
			padding: 30px 30px 30px 30px;
		}
		#regformdiv {
			margin: 30px 30px 30px 30px;
			padding: 20px 50px 20px 50px;
			background: white;

		}
		#notice{
			color: red;
			font-family: lucida;
			font-size: x-large;
		}
		.glowing{
		    		text-shadow:
		  0 0 5px #fff700, 0 0 10px #fff700,
		  0 0 20px #fff700, 0 0 40px #fff700;
		  font-style: italic;
		  font-family: lucida;
		  font-size: 50px;
		  font-weight: bolder;
		  /*background-color: black;
		  color: white;*/

		    	}
		    	.row{
		    		padding-left: 30px;
		    	}

		    	#sectionnames{
		    		padding: 30px 30px 70px 30px;
		    		margin: 30px 30px 70px 30px;
		    		color: indigo;
		    		font-size: 28px;
		    		font-family: Arial;
		    		text-decoration: underline;
		    	}

	</style>
	<br> <br> 
	<form action="insertsignup.php" method="post">
	<section class="regform">
		<section class="form" id="regformdiv">
			<center>
			<h1 class="glowing">Sign up to create your own login</h1>
			</center>
			<div class="row">
				<div class="col-md-12">
					
				
					<span id ="notice"> Note: Please fill all details wisely and precisely. Make sure it is true and correct.
						<br><br></span>
				</div>
			</div>
				

			<div class="row">		
			<div class="col-md-12">
				<span id="sectionnames"><b>Section 1:</b> Personal Information</span><br><br>
			</div>		
				<div class="col-md-6">					
						<div class="form-group">
						    <label for="name"><h5>Name<span style="color:red;">*</span></h5></label>
						    <input type="text" class="form-control" id="name" aria-describedby="" required name="name">
						    <small id="help" class="form-text text-muted">Please enter your full name</small>
						  </div>

						  <div class="form-group">
						    <label for="age"><h5>Age<span style="color:red;">*</span></h5></label>
						    <input type="text" class="form-control" id="age" aria-describedby="" required name="age">

						<div class="form-group">
					      <label for="age"><h5>Select Age:<span style="color:red;">*</span></h5></label>
					      <select id="age" class="form-control">
					        <option selected>18-20</option>
					        <option>21-30</option>
					        <option>31-40</option>
					        <option>41-60</option>
					      </select>
					    </div>
						    <small id="help" class="form-text text-muted">Enter your exact age. Age groups not available are not eligible for login creation</small>
						  </div>
					
				</div>

				<div class="col-md-6">
					<div class="form-group">
						    <label for="contact"><h5>Contact<span style="color:red;">*</span></h5></label>
						    <input type="text" class="form-control" id="contact" aria-describedby="" required name="contact">
						    <small id="help" class="form-text text-muted">Contact should be working (can be used for delivery or enquiries)</small>
						  </div>

						  <div class="form-group">
						    <label for="gender"><h5>Gender<span style="color:red;">*</span></h5></label>
						    <br>
						    <input type="radio" id="gender" name="gender" value="male"/> Male    <br>  
							<input type="radio" id="gender" name="gender" value="female"/> Female <br/>
							<input type="radio" id="gender" name="gender" value="other"/> Other(Rather not say) <br/>
						    <small id="help" class="form-text text-muted">Select Gender</small>
						  </div>
					
				</div>				
			</div>

			<div class="row">		
			<div class="col-md-12">
				<span id="sectionnames"><b>Section 2:</b> Mail and address</span><br><br>
			</div>		
				<div class="col-md-6">					
						<div class="form-group">
						    <label for=""><h5>E-mail ID<span style="color:red;">*</span></h5></label>
						    <input type="email" class="form-control" id="email" aria-describedby="" required name="email">
						    <small id="help" class="form-text text-muted">E-mail should be verified and working</small>
						  </div>
				</div>
				<div class="col-md-6">

						  <div class="form-group">
						    <label for="address"><h5>Address<span style="color:red;">*</span></h5></label>
						    <input type="text" class="form-control" id="address" aria-describedby="" required name="address">
						    <small id="help" class="form-text text-muted">Enter your current address</small>
						  </div>
				</div>
					
				</div>


				<div class="row">		
			<div class="col-md-12">
				<span id="sectionnames"><b>Section 3:</b> Precise address</span><br><br>
			</div>		
				<div class="col-md-6">					
						<div class="form-group">
						    <label for="pincode"><h5>Pin Code(Postal Identification Number):<span style="color:red;">*</span></h5></label>
						    <input type="text" class="form-control" id="pincode" aria-describedby="" required name="pincode">
						    <small id="help" class="form-text text-muted">Enter 6 digit pincode</small>
						  </div>

						<div class="form-group">
						    <label for="state"><h5>State:<span style="color:red;">*</span></h5></label>
						    <input type="text" class="form-control" id="state" aria-describedby="" required name="state">
						    <small id="help" class="form-text text-muted">Enter state , a valid state</small>
						  </div>
						  
						  <div class="form-group">
						    <label for="country"><h5>Country:<span style="color:red;">*</span></h5></label>
						    <input type="text" class="form-control" id="country" aria-describedby="" required name="country">
						    <small id="help" class="form-text text-muted">Enter valid country</small>
						  </div>  
				</div>
				<div class="col-md-6">

						  <div class="form-group">
						    <label for="district"><h5>District<span style="color:red;">*</span></h5></label>
						    <input type="text" class="form-control" id="district" aria-describedby="" required name="district">
						    <small id="help" class="form-text text-muted"> Enter your district</small>
						  </div>
						  <div class="form-group">
						    <label for="towncity"><h5>Town/city:<span style="color:red;">*</span></h5></label>
						    <input type="text" class="form-control" id="towncity" aria-describedby="" required name="towncity">
						    <small id="help" class="form-text text-muted">Enter your town/city or village  </small>
						  </div>
				</div>
					
				</div>

				<div class="row">
					<div class="col-md-12">
						<span id="sectionnames"><b>Section 4:</b> Relative's contact Information</span><br><br>
					</div>
					<div class="col-md-6">
						<div class="form-group">
						    <label for="relativename"><h5>Relative's Full name:</h5></label>
						    <input type="text" class="form-control" id="relativename" aria-describedby="" required name="relativename">
						    <small id="help" class="form-text text-muted">You must give your relatives full name   </small>
						  </div>
						  <div class="form-group">
						    <label for="relativecontact"><h5>Relative's contact number:</h5></label>
						    <input type="text" class="form-control" id="relativecontact" aria-describedby="" required name="relativecontact">
						    <small id="help" class="form-text text-muted">You must give your relative's working contact number  </small>
						  </div>
						
					</div>
					<div class="col-md-6">
						<div class="form-group">
						    <label for="relativeaddress"><h5>Relative's Address:</h5></label>
						    <input type="text" class="form-control" id="relativeaddress" aria-describedby="" required name="relativeaddress">
						    <small id="help" class="form-text text-muted">You must give your relative's address in short </small>
						  </div>

						  <div class="form-group">
						    <label for="relation"><h5>Your relation with them:</h5></label>
						    <input type="text" class="form-control" id="relation" aria-describedby="" required name="relation">
						    <small id="help" class="form-text text-muted">Specify how you are related to them   </small>
						  </div>
						
					</div>

					
				</div>



			<div class="row">
				<div class="col-md-12">
				<span id="sectionnames"><b>Section 5:</b> Login credetials generation and confirmation</span><br><br>
			</div>
				<div class="col-md-6">
					      <div class="form-group">
						    <label for="username"><h5>User Name<span style="color:red;">*</span></h5></label>
						    <input type="text" class="form-control" id="username" aria-describedby="" required name="username">
						    <small id="help" class="form-text text-muted">Enter a user name that will help you to login</small>
						  </div>
				</div>
				<div class="col-md-6">	

						  <div class="form-group">
						    <label for="password"><h5>Password<span style="color:red;">*</span></h5></label>
						    <input type="password" class="form-control" id="password" aria-describedby="" required name="password">
						    <small id="help" class="form-text text-muted">Enter a strong password for accessing your login</small>
						  </div>

						  <div class="form-group">
						    <label for="confirmpassword"><h5>Confirm Password<span style="color:red;">*</span></h5></label>
						    <input type="password" class="form-control" id="confirmpassword" aria-describedby="" required name="confirmpassword">
						    <small id="help" class="form-text text-muted">Please confirm your password</small>
						  </div>
					
				</div> <!-- eof colmd6 of section 5 -->
				
			</div>

			<div class="col-md-12">
			  <div class="form-check">
			    <input type="checkbox" class="form-check-input" id="check" required>
			    <label class="form-check-label" for="check">I accept and hereby admit that all information filled above is true and correct and I shall be liable of any discrepancies if found</label>
			  </div>
				  <br><br>
				  <input type="button" style = "font-size: 25px;"name="confirming" class="btn btn-success" value="Confirm sign up" onclick="window.confirm('Are you sure you want to sign up? Please click OK and submit the form')">
				  &nbsp;
				  &nbsp;
				  &nbsp;
				  &nbsp;
							  
				  <input type="reset" name="reset" class="btn btn-danger" style = "font-size: 25px;" value="Cancel/reset">
				  &nbsp;
				  &nbsp;
				  &nbsp;
				  &nbsp;
				  <input type="submit" value="Submit" style = "font-size: 25px;"name="submitsignup" class="btn btn-warning" onclick="checkpass()">
				  &nbsp;
				  &nbsp;
				  &nbsp;
				  &nbsp;
			</div><!-- eof col-md-12 -->
			
		</div>  <!-- eof col-md-12 -->
		</div>
			
		</section>
	</section>
</form>



</body>
</html>


<?php
	include 'footing.php';			
?>