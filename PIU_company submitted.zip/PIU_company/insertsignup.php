<title>Sign up confirmation</title>
<?php include('element.php'); ?>
<body style="background: url('https://images.pexels.com/photos/733852/pexels-photo-733852.jpeg?auto=compress&cs=tinysrgb&w=1000'); background-size: cover; background-attachment: fixed;">

<?php 
		include 'heading.php';
		div_space();
		div_space();
?>
<?php 
		
	    require_once('dbconnect.php');

	    $name = $_POST['name'];
	    $contact = $_POST['contact'];
	    $age = $_POST['age'];
	    $gender = $_POST['gender'];
	    $email = $_POST['email'];
	    $username = $_POST['username'];
	    $password = $_POST['password'];
	    $confirmpassword = $_POST['confirmpassword'];
	    $state = $_POST['state'];
	    $pincode = $_POST['pincode'];
	    $district = $_POST['district'];
	    $towncity = $_POST['towncity'];
	    $relation = $_POST['relation'];
	    $relativeaddress = $_POST['relativeaddress'];
	    $country = $_POST['country'];
	    $relativename = $_POST['relativename'];
	    $relativecontact = $_POST['relativecontact'];
	    $address = $_POST['address'];


	    $sql = "Insert into signup
	    (
	     name,
	     contact, 
	     email,
	     username,
	     password,
	     confirmpassword,
	     relativecontact,
	     relativename,
	     relation,
	     relativeaddress,
	     state,
	     country,
	     pincode,
	     address,
	     gender,
	     age,
	     towncity,
	     district
	 	)
	 	values
	 	(
	 	'$name',
	 	'$contact',
	 	'$email',
	 	'$username',
	 	'$password',
	 	'$confirmpassword',
	 	'$relativecontact',
	 	'$relativename',
	 	'$relation',
	 	'$relativeaddress',
	 	'$state',
	 	'$country',
	 	'$pincode',
	 	'$address',
	 	'$gender',
	 	'$age',
	 	'$towncity',
	 	'$district'

	 	)";

	$run=mysqli_query($conn,$sql );
	echo"<br> <br> <br> <br><br> <h1> Registered successfully!!!</h1><br><h1> Thankyou for registering:) Now you can login through your username and password</h1><br> <br> <br>";

	
?>
</body>
<?php 
		include 'footing.php';
		//div_space();
?>

