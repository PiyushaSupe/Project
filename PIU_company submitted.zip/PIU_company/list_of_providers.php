<?php	
	require('dbconnect.php');
	include ('heading.php');
	include ('element.php');
	//include ('');
	require_once('./php/component.php');
	require_once('./php/CreateDb.php');

	    //create instance of CreateDb class
	$database = new CreateDb("Productdb","reg_person");
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>list of service providers</title>
	<!-- font awesome links -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" >
	<link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css">

			<!--bootstrap css links -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
			<!-- bootstrap js links -->
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
</head>
<body>
	<style type="text/css">
		#printing{
			border: 4px solid ;
			padding: 10px 100px 100px 100px;
			margin: 100px 100px 100px 100px;
			background: white;
			background: url('https://images.pexels.com/photos/164572/pexels-photo-164572.jpeg?auto=compress&cs=tinysrgb&w=2000');


		}
		body{
			
			background-size: cover;
		
		}

		#tableproviders{
			border: 2px solid snow;
			padding: 20px 20px 20px 20px;
			margin: 30px 30px 30px 30px;
			font-style: georgia;
			font-size: 20px;
		}
		th{
			background: lightskyblue;
			color: black;
		}
	</style>
<section id="printing">

	<?php div_space();?>

	<h1>List of service providers </h1>
<div class="row">
	<div class="col-md-12">
	<table border="2px solid" id="tableproviders" class="table table-hover table-dark">
		<tr>
			<th>ID</th>
			<th>Name</th>
			<th>Contact</th>
			<th>Mail</th>
			
		</tr>
      <?php
			$result = $database->getData();
			while($row = mysqli_fetch_assoc($result)){
				provider($row['name'],$row['contact'],$row['mail'], $row['id']);
			}
			//div_space();
		
		?>
	</table>
</div>
</div>
</section>
</body>
</html>

<?php
	include 'footing.php';			
?>