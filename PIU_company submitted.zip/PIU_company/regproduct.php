<title>Register a new product in the database</title>
<?php 
		require_once('./php/component.php');
	    require_once('./php/CreateDb.php');

	    //create instance of CreateDb class
	//$database = new CreateDb("Productdb","userdata");


?>

<?php include('element.php'); ?>
<?php 
		include 'heading.php';
		div_space();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- font awesome links -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" >
	<link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css">

			<!--bootstrap css links -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
			<!-- bootstrap js links -->
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
	
</head>
<body>
	<style type="text/css">
		.regform{
			background: url('https://images.pexels.com/photos/129728/pexels-photo-129728.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1');
			margin: 30px 30px 30px 30px;
			padding: 30px 30px 30px 30px;
		}
		#regformdiv {
			margin: 30px 30px 30px 30px;
			padding: 20px 50px 20px 50px;
			background: white;

		}
		#notice{
			color: red;
			font-family: lucida;
			font-size: x-large;
		}
		.glowing{
		    		text-shadow:
		  0 0 5px #fff700, 0 0 10px #fff700,
		  0 0 20px #fff700, 0 0 40px #fff700;
		  font-style: italic;
		  font-family: lucida;
		  font-size: 50px;
		  font-weight: bolder;
		  /*background-color: black;
		  color: white;*/

		    	}

	</style>
	<marquee><h4><span class="badge badge-secondary">New</span>Once registered you can see yourself on list of service providers!        Feel free to register any new service you wish to offer through our portal</h4></marquee>
	<section class="regform">
		<section class="form" id="regformdiv">
			<center>
			<h1 class="glowing">Registration of a new service</h1>
			</center>
			<div class="row">
				<div class="col-md-12">
					
				
					<span id ="notice">Note: Everyone is free to register the services but if any discrepancies are found then they shall be liable for legal procedures for safety and security of our firm and our clients 
						<br><br></span>
			<form action="insertproduct.php" method="post">

				<div class="form-group">
				    <label for="person"><h5>Name of person registering<span style="color:red;">*</span></h5></label>
				    <input type="text" class="form-control" id="person" aria-describedby="" required name="person">
				    <small id="help" class="form-text text-muted">This is the name of the person registering the service</small>
				  </div>

				  <div class="form-group">
				    <label for="mail"><h5>E-mail of person registering:<span style="color:red;">*</span></h5></label>
				    <input type="email" class="form-control" id="mail" aria-describedby="" required name="mail">
				    <small id="help" class="form-text text-muted">Give a valid mail ID</small>
				  </div>

				  <div class="form-group">
				    <label for="contact"><h5>CONTACT<span style="color:red;">*</span></h5></label>
				    <input type="text" class="form-control" id="contact" aria-describedby="" required name="contact">
				    <small id="help" class="form-text text-muted"></small>
				  </div>

				<div class="form-group">
				    <label for="productname"><h5>Name of service<span style="color:red;">*</span></h5></label>
				    <input type="text" class="form-control" id="productname" aria-describedby="" required name="nameofservice">
				    <small id="help" class="form-text text-muted">This is the name of the service that you wish to register</small>
				  </div>

				  <div class="form-group">
				    <label for="productname"><h5>Price of service offered in rupees(&#8377;)<span style="color:red;">*</span></h5></label>
				    <input type="text" class="form-control" id="productname" aria-describedby="" required name="priceofservice">
				    <small id="help" class="form-text text-muted">This is the price of the service that you wish to register</small>
				  </div>

				  <div class="form-group">
				    <label for="companyname"><h5>Company Name <span style="color:red;">*</span></h5></label>
				    <input type="text" class="form-control" id="companyname" aria-describedby="" required name="servicecompany">
				    <small id="help" class="form-text text-muted">please mention company name that wishes to offer this service</small>
				  </div>

				  <div class="form-group">
				    <label for="imageurl"><h5>Image of service offered <span style="color:red;">*</span></h5></label>
				    <input type="text" class="form-control" id="imageurl" aria-describedby="" required name="image">
				    <small id="help" class="form-text text-muted">Give a presentable picture of the service (for displaying on website carts) Make sure it is a url</small>
				  </div>

				  <div class="form-group">
				    <label for="describe"><h5>Provide a feasible description about the service<span style="color:red;">*</span></h5></label>
				    <textarea class="form-control" id="describe" rows="3" placeholder="The best laundry and dry cleaning at home pick up and delivery service" required name="descofservice"></textarea>
				  </div>
				  <br><br>
				  <input type="button" style = "font-size: 25px;"name="confirming" class="btn btn-success" value="Register Service" onclick="window.confirm('Are you sure you want to register service? Please click OK and submit the form')">
				  &nbsp;
				  &nbsp;
				  &nbsp;
				  &nbsp;
				  <input type="submit" style = "font-size: 25px;"name="regproduct" class="btn btn-info">
				  &nbsp;
				  &nbsp;
				  &nbsp;
				  &nbsp;
				  <input type="reset" name="reset" class="btn btn-warning" style = "font-size: 25px;">
				  &nbsp;
				  &nbsp;
				  &nbsp;
				  &nbsp;
				  
			
			</form>
		</div>
		</div>
			
		</section>
	</section>



</body>
</html>


<?php
	include 'footing.php';			
?>