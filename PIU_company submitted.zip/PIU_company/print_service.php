<?php include('element.php'); ?>
<?php 
		include 'heading.php';
		div_space();
?>

<?php	
	require('dbconnect.php');

	function printing($person, $con, $mail, $service, $price, $company, $describe){
		$element = "<center><p style=\"font-size : 25px; \">
		<br>
		<img src = \"piuclogo.jpg\" width = \"300px\" height = \"100px\" >
		<br>
		<table style = \"text-align:center; border:3px solid;padding:20px 20px 20px 20px; \">
						<tr colspan = \"2\">
						<th>Service registered by you </th>					
						</tr>

						<tr>
						<th>Name: </th>
						<td>$person </td>
						</tr>

						<tr>
						<th>Contact: </th>
						<td> $con</td>
						</tr>

						<tr>
						<th>Email: </th>
						<td>$mail </td>
						</tr>

						<tr>
						<th>Service: </th>
						<td>$service </td>
						</tr>

						<tr>
						<th>Sevice price: </th>
						<td>$price </td>
						</tr>

						<tr>
						<th>Company name: (service provider): </th>
						<td>$company </td>
						</tr>

						<tr>
						<th>Description: </th>
						<td>$describe </td>
						</tr>
		</table> 
		
		</p></center>
		<img src = \"digisign.jpg\" width = \"200px\" height = \"100px\" >";
		echo $element;
	}

	
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Your service register details</title>

	<script>
				function printpart () {
				  var printwin = window.open("");
				  printwin.document.write(document.getElementById("toprint").innerHTML);
				  //printwin.stop();
				  printwin.print();
				  //printwin.close();
				}
</script>

	<!-- font awesome links -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" >
	<link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css">

			<!--bootstrap css links -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
			<!-- bootstrap js links -->
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

    <style type="text/css">
    	
    	.glowing{
		    		text-shadow:
		  0 0 5px #fff700, 0 0 10px #fff700,
		  0 0 20px #fff700, 0 0 40px #fff700;
		  font-style: italic;
		  font-family: lucida;
		  font-size: 50px;
		  font-weight: bolder;
		  /*background-color: black;
		  color: white;*/

		    	}

		.regform{
			background: url('https://images.pexels.com/photos/268415/pexels-photo-268415.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1');
			margin: 30px 30px 30px 30px;
			padding: 30px 30px 30px 30px;
		}
		#regformdiv {
			margin: 30px 30px 30px 30px;
			padding: 20px 50px 20px 50px;
			background: white;
			font-weight: bold;
			font-size: 20px;

		}
		#printbutton{
			font-size: 30px;
		}

		#toprint{
			border: 3px solid lightgray;
			margin: 30px 30px 30px 30px;
			padding: 20px 50px 20px 50px;
			font-size: 30px;
			font-weight: lighter;
			font-family: georgia;
		}
		table , th, td {
			border: 3px solid;
		}

    </style>
</head>
<body>
	<marquee><h4><span class="badge badge-secondary">Scroll the page</span>&nbsp; &nbsp;Click the print button to print a PDF file!  :)</h4></marquee>
<section class="regform">
<section id="regformdiv">
<section id="toprint">

	<h1><center>Your service details are: </center></h1>
	<?php
	$name = $_POST['name'];
	$company = $_POST['company'];
	$mail = $_POST['mail'];
	$service = $_POST['service'];

	if(isset($_POST['print']))
	{
		$sql1 = "Select * from reg_person where name = '$name' and mail = '$mail'";
		$sql2 = "Select * from producttb where product_name = '$service' and companyname = '$company'";

		$run1=mysqli_query($conn,$sql1);
		$run2=mysqli_query($conn,$sql2);

		 $result1 = mysqli_fetch_assoc($run1);
		 $result2 = mysqli_fetch_assoc($run2);

		 printing($result1['name'],$result1['contact'],$result1['mail'],$result2['product_name'],$result2['product_price'],$result2['companyname'],$result2['description']
		 );


	}	 
		 //printing($person, $con, $mail, $service, $price, $company, $describe)
	?>


</section>
</section>
<center>
<input type="button" id="printbutton" value="Print" onclick="printpart()" name="sectionprint" class="btn btn-warning" /></center>
</section>
</body>
</html>
<?php include 'footing.php'; ?>