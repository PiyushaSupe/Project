

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Piu company</title>

	<!-- font awesome links -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" >
	<link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css">

			<!--bootstrap css links -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
			<!-- bootstrap js links -->
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>


    <style type="text/css">
    	
    	footer{
    		width: 100%;
    		background-size: cover;
    	}
    	.container-fluid{
    		width: 100%;

    	}
    	
    </style>
</head>		<!-- Remove the container if you want to extend the Footer to full width. -->							
							  <!-- Footer -->
							  <footer
							          class="text-center text-lg-start text-white"
							          style="background-color: #1c2331;width:100%; left: 0;right: 0;"
							          >
							    <!-- Section: Social media -->
							    <section
							             class="d-flex justify-content-between p-4"
							             style="background-color: indigo; "
							             >
							      <!-- Left -->
							      <div class="me-5">
							        <span>Get connected with us on social networks:</span>
							      </div>
							      <!-- Left -->

							      <!-- Right -->
							      <div>
							        <a href="https://www.facebook.com/" class="text-white me-4">
							          <i class="fab fa-facebook-f"></i>
							        </a> &nbsp;
							        <a href="https://twitter.com/" class="text-white me-4">
							          <i class="fab fa-twitter"></i>
							        </a>&nbsp;
							        <a href="https://www.google.com/" class="text-white me-4">
							          <i class="fab fa-google"></i>
							        </a>&nbsp;
							        <a href="https://www.instagram.com/" class="text-white me-4">
							          <i class="fab fa-instagram"></i>
							        </a>&nbsp;
							        <a href="" class="text-white me-4">
							          <i class="fab fa-linkedin"></i>
							        </a>&nbsp;
							        <a href="" class="text-white me-4">
							          <i class="fab fa-github"></i>
							        </a>&nbsp;
							      </div>
							      <!-- Right -->
							    </section>
							    <!-- Section: Social media -->

							    <!-- Section: Links  -->
							    <section class="">
							      <div class="container text-center text-md-start mt-5">
							        <!-- Grid row -->
							        <div class="row mt-3">
							          <!-- Grid column -->
							          <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
							            <!-- Content -->
							            <h6 class="text-uppercase fw-bold">Phenomenal Infrastructure Utility Company </h6>
							            <hr
							                class="mb-4 mt-0 d-inline-block mx-auto"
							                style="width: 60px; background-color: #7c4dff; height: 2px"
							                />
							            <p>
							              This company solely focuses on the objective of providing services to the clients. The services are managed thoroughly and we try to strive for remarkable fixing and repairing and servicing to make our clients 100% satisfied. 
							            </p>
							          </div>
							          <!-- Grid column -->

							          <!-- Grid column -->
							          <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
							            <!-- Links -->
							            <h6 class="text-uppercase fw-bold">Services</h6>
							            <hr
							                class="mb-4 mt-0 d-inline-block mx-auto"
							                style="width: 60px; background-color: #7c4dff; height: 2px"
							                />
							            <p>
							              Interior repairing
							            </p>
							            <p>
							              Electrical appliances repairing
							            </p>
							            <p>
							              Automobile servicing
							            </p>
							            <p>
							              House Painting
							            </p>
							            <p>
							              Waterproofing of ceiling
							            </p>
							          </div>
							          <!-- Grid column -->

							          <!-- Grid column -->
							          <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
							            <!-- Links -->
							            <h6 class="text-uppercase fw-bold">Useful links</h6>
							            <hr
							                class="mb-4 mt-0 d-inline-block mx-auto"
							                style="width: 60px; background-color: #7c4dff; height: 2px"
							                />
							            <p>
							              <a href="loginpage.php" class="text-white">Login to Your Account</a>
							            </p>
							            <p>
							              <a href="https://piyushasupe.blogspot.com/" class="text-white">Blogs</a>
							            </p>
							            <p>
							              <a href="shiprate.php" class="text-white">Shipping Rates</a>
							            </p>
							            <p>
							              <a href="about.php" class="text-white">About/Get to know us</a>
							            </p>
							            <p>
							              <a href="privacy.php" target ="_self" class="text-white">PRIVACY POLICY</a>
							            </p>
							            <p>
							              <a href="index_piu_company.php" class="text-white">Go to main page</a>
							            </p>
							          </div>
							          <!-- Grid column -->

							          <!-- Grid column -->
							          <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
							            <!-- Links -->
							            <h6 class="text-uppercase fw-bold">Contact</h6>
							            <hr
							                class="mb-4 mt-0 d-inline-block mx-auto"
							                style="width: 60px; background-color: #7c4dff; height: 2px"
							                />
							            <p><i class="fas fa-home mr-3"></i> INDIA</p>
							            <p><i class="fas fa-envelope mr-3"></i> help_enquiry@piucompany.com</p>
							            <p><i class="fas fa-phone mr-3"></i> + 01 234 567 88</p>
							            <p><i class="fas fa-print mr-3"></i> + 01 234 567 89</p>
							            <p>
							            <i class="fa-solid fa-location-dot">&nbsp;Location</i><br><br>
							            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387190.279909073!2d-74.25987368715491!3d40.69767006458873!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2sin!4v1661511327243!5m2!1sen!2sin" width="200" height="200" style="border:3px solid ghostwhite;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
							            </p>


							          </div>
							          <!-- Grid column -->
							        </div>
							        <!-- Grid row -->
							      </div>
							    </section>
							    <!-- Section: Links  -->

							    <!-- Copyright -->
							    <div
							         class="text-center p-3"
							         style="background-color: rgba(0, 0, 0, 0.2)"
							         >
							      © 2022 Copyright:
							      <a class="text-white" href="#"
							         >Piyusha Rajendra Supe </a
							        >
							    </div>
							    <!-- Copyright -->
							  </footer>
							  <!-- Footer -->

				<div id="down" style="position: fixed; bottom: 0; right: 0;">&#169; Copyright 2022 Piyusha Supe All rights reserved &nbsp;</div>		

	
