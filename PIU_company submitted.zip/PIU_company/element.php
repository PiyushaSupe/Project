<?php

function div_space(){
	$element="
	<style>
		#spaced{
	height: 100px;
	width :100%;
	opacity: 0;
	}

	</style>
	<div id=\"spaced\">

	</div>

	";
	echo $element;
}


?>