<!-- font awesome links -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" >
  <link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css">

      <!--bootstrap css links -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
      <!-- bootstrap js links -->
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

<style type="text/css">
  /*img{
    border: 3px solid white;
    border-radius: 20px;
  }*/
  .carousel-caption{
    color: darkred;
    font-size: 30px;
    font-weight: bolder;
    text-underline-position: bottom;
  }
  .carousel{
    padding: 50px 50px 50px 50px;
  }
</style>

<div class="container-fluid"> 
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="6"></li>
    
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://images.pexels.com/photos/4254164/pexels-photo-4254164.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" class="d-block w-100" alt="electrician">
      <div class="carousel-caption d-none d-md-block">
        <h5>Solar panel fixing</h5>
        <p>Call professionals at your doorstep! to repair and fix solar panels </p>
      </div>

    </div>
    <div class="carousel-item">
      <img src="https://images.pexels.com/photos/8853525/pexels-photo-8853525.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>Electrical repairing</h5>
        <p>We take responsibility for all kinds of electrical work to be done with all safety and precautions</p>
      </div>

    </div>
    <div class="carousel-item">
      <img src="https://images.pexels.com/photos/6419128/pexels-photo-6419128.jpeg?auto=compress&cs=tinysrgb&w=400" class="d-block w-100" alt="...">
    <div class="carousel-caption d-none d-md-block">
        <h5>Plumbing</h5>
        <p>Shower stopped working? No worries! Avail our service for perfect fixing by trained professionals</p>
      </div>

    </div>
    <div class="carousel-item">
      <img src="https://media.istockphoto.com/photos/mechanic-technician-on-a-garage-picture-id511317032?b=1&k=20&m=511317032&s=612x612&w=0&h=uLp4Dz3fhD0hsJxaRkZqB0P3oKwRB7a-Mi7cCpG76EE=" class="d-block w-100" alt="...">
    <div class="carousel-caption d-none d-md-block">
        <h5>Car and automobile repairing services</h5>
        <p>Reach out to us for on spot car or automobile repairing services </p>
      </div>

    </div>
    <div class="carousel-item">
      <img src="https://media.istockphoto.com/photos/water-flood-and-pipe-leak-picture-id1316933921?b=1&k=20&m=1316933921&s=612x612&w=0&h=q8e0OpzednS9KT7XqJzHMlkPkNI8mRILRvkWOIyQMz4=" class="d-block w-100" alt="...">
    <div class="carousel-caption d-none d-md-block">
        <h5>Ceiling water-proofing</h5>
        <p>We provide the best water-proofing services and in time fixings </p>
      </div>

    </div>
    <div class="carousel-item">
      <img src="https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" class="d-block w-100" alt="...">
    <div class="carousel-caption d-none d-md-block">
        <h5>Laptop and Computer repairing</h5>
        <p>For any replacement of parts and laptop or computer repairing we provide services that collect your device and deliver it fixed within a due time</p>
      </div>

    </div>
    <div class="carousel-item">
      <img src="https://images.pexels.com/photos/7546562/pexels-photo-7546562.jpeg?auto=compress&cs=tinysrgb&w=400" class="d-block w-100" alt="...">
    <div class="carousel-caption d-none d-md-block">
        <h5>Interior Designing professional</h5>
        <p>Bought a new house? We will help you to make it a house of your dreams and redirect you to the best interior designing portals out there!</p>
      </div>

    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-target="#carouselExampleIndicators" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-target="#carouselExampleIndicators" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </button>
</div>
</div>