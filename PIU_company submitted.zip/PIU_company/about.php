<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>About PIU company</title>

	<!-- font awesome links -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" >
	<link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css">

			<!--bootstrap css links -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
			<!-- bootstrap js links -->
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
<style type="text/css">
	
	p{
		text-align: justify-all;

	}

	.glowing{
		    		text-shadow:
		  0 0 5px #fff700, 0 0 10px #fff700,
		  0 0 20px #fff700, 0 0 40px #fff700;
		  font-style: italic;
		  font-family: lucida;
		  font-size: 50px;
		  font-weight: bolder;
		  /*background-color: black;
		  color: white;*/

		    	}
</style>


</head>
<body>
<div class="container-fluid">
		<?php 
			include 'heading.php';
		?>
		<br> <br>
		<center>
			<h1 class="glowing">Why must you choose us? </h1>
			<p>
			<img src="whypiuc.png" width="600px" height="600px"  id="whyus"/>
			</p>
		<br> <br> <br>
		</center>
	<center><h1 style="font-size: 45px;  text-shadow: 2px 3px cyan; width: 100%; background: ; color: ; padding-bottom:10px ;">About us</h1>

		
			<!-- https://images.pexels.com/photos/845451/pexels-photo-845451.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1

		https://images.pexels.com/photos/1409999/pexels-photo-1409999.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1

		https://images.pexels.com/photos/372810/pexels-photo-372810.jpeg?auto=compress&cs=tinysrgb&w=400


		https://images.pexels.com/photos/4239035/pexels-photo-4239035.jpeg?auto=compress&cs=tinysrgb&w=400 -->

		<section id="paper" style="padding: 10px 10px 10px 10px;margin: 20px 20px 20px 20px; border: 2px solid; 
		background: linear-gradient(to right, #ccffff 0%, #ffffff 100%);">
		


		<p style="
		font-size:20px; 
		
		">
				<h3 style="
				font-size: 30px; 
				font-style: italic;
				">Get to know me first...</h3>

<p style="
		font-size:20px; 
		
		">
			<br>This webiste is created by<b> Piyusha Supe</b> (myself) from scratch and from the very start, by watching tutorials and trial and error technique. With the feeling of utmost pleasure I gladly state that I have spent almost 10 hours per day for 15 days and that I have learnt a lot and will enjoy unveiling this new part of my life. With lots of thrill about what comes next I keep on living every day to the fullest!
			<br>Good day everyone!  <br></p>
					<h3 style="
				font-size: 30px; 
				font-style: italic;
				">WHO ARE WE?</h3>
				<p style="
		font-size:20px; 
		
		">
			We are a startup that strives for providing at home services at your doorstep with just a few clicks you will be able to avail our services any time and anywhere
		</p>
		<h3 style="font-size: 30px; font-style: italic;">WHY US?</h3>
		<p style="font-size:20px;">
			Our portal helps you to garner all the home related services and electronic repair servicing kind of services at a few clicks. There are not many who assure you completely. So here we are! We provide the most quality assured services so that you and your house and all your devices stay as healthy as possible.
		</p>
		<br>
		<p style="font-size:30px;">
			 
		</p>

			<section style="left: 0;">
			<div class="row" >
				<style type="text/css">
					.card{
						padding: 10px 10px 10px 10px;
						margin: 20px 20px 20px 20px;
						left: 0;
						height: 430px;
						width: 200px;
						 background: linear-gradient(to bottom, #ffccdd 0%, #d9b3ff 100%);
					}
				</style>
					
				<h3 style="font-size: 30px; font-style: italic; color: indigo;">OUR TEAM</h3>

				<div class="col-md-3">
					<div class="card" style="width: 200px;">
					  <img style="width:150px;height: 150px;"  class="card-img-top" src="https://simg.nicepng.com/png/small/176-1765177_businesswoman-portrait-silhouette-female-icon-avatar-business-woman.png" align="center" alt="...">
					  <div class="card-body">
					  	<h4>Piyusha</h4>
					    <p class="card-text">Lead analyst and founder of PIU company and the pillar for growth of the company</p>
					  </div>
					</div>
				</div>

				<div class="col-md-3">
					<div class="card" style="width: 200px;">
					  <img style="width:150px;height: 150px;" src="https://simg.nicepng.com/png/small/176-1765177_businesswoman-portrait-silhouette-female-icon-avatar-business-woman.png" align="center"  class="card-img-top" alt="...">
					  <div class="card-body">
					  	<h4>Ellie</h4>
					    <p class="card-text">Efficient marketting team head whp plays a significant role throughout</p>
					  </div>
					</div>					
				</div>

				<div class="col-md-3">
					<div class="card" style="width: 200px;">
					  <img style="width:150px;height: 150px;" src="https://thumbs.dreamstime.com/b/user-woman-icon-lady-s-profile-female-web-sign-flat-art-object-black-white-silhouette-girl-business-suit-avatar-picture-173159996.jpg" align="center" class="card-img-top" alt="...">
					  <div class="card-body">
					  	<h4>Cindy</h4>
					    <p class="card-text">Website designer and front-end web developer for this portal</p>
					  </div>
					</div>					
				</div>

				<div class="col-md-3">	
					<div class="card" style="width: 200px;">
					  <img style="width:150px;height: 150px;" src="https://previews.123rf.com/images/djvstock/djvstock1608/djvstock160808204/61261167-man-male-avatar-silhouette-person-icon-isolated-and-flat-illustration-vector-graphic.jpg" align="center" alt="...">
					  <div class="card-body">
					  	<h4>Chinmay</h4>
					    <p class="card-text">Budding market and E-commerce person, who generates new marketting strategies</p>
					  </div>
					</div>				
				</div>
				

			</div>
			
			</section>
			<h3 style="font-size: 30px; font-style: italic; color: indigo;">SOME OF OUR SERVICES AND PERKS</h3>
			<p style="font-size:20px;"> 

				<img src="https://images.pexels.com/photos/845451/pexels-photo-845451.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" class="rounded mx-auto d-block" alt="..." width="500px" height="300px"><br>
				<caption>We provide 24/7 customer support</caption><br>

				<p style="font-size:20px;"><b>24/7 </b>support (also popularly known as 24/7 customer service or 24/7 tech support) is a customer service strategy that involves providing support 24 hours a day, and 7 days a week. In other words, a 24/7 support model ensures that a customer is able to get their issue resolved no matter what day or time it is</p>
				<br> <br>

				<img src="https://images.pexels.com/photos/1409999/pexels-photo-1409999.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" class="rounded mx-auto d-block" alt="..."><br>
				<caption>Automobile Repairing service</caption><br>

				<p style="font-size:20px;">A motor vehicle service or tune-up is a series of maintenance procedures carried out at a set time interval or after the vehicle has traveled a certain distance. The service intervals are specified by the vehicle manufacturer in a service schedule and some modern cars display the due date for the next service electronically on the instrument panel. A tune-up should not be confused with engine tuning, which is the modifying of an engine to perform better than the original specification, rather than using maintenance to keep the engine running as it should</p>
				<br> <br>

				<img src="https://images.pexels.com/photos/372810/pexels-photo-372810.jpeg?auto=compress&cs=tinysrgb&w=400" class="rounded mx-auto d-block" alt="..."><br>
				<caption>Car servicing </caption><br>

				<p style="font-size:20px;"><b>Inspection </b>- vehicle components are visually inspected for wear or any leaks. A diagnostic is performed to identify any electrical components reporting a failure or a part operating outside of normal conditions.<br>
				<b>Replacement </b>- Given certain lubricants break down over time due to heat and wear, manufacturers recommend replacement. Any parts that are close to their expected failure are replaced too to avoid a failure while operating the vehicle.<br>
				<b>Adjustments</b> - as vehicle components wear, they may need adjustment over time. Example: parking brake cable.<br>
				The completed services are usually recorded in a service book upon completion of each service. A complete service history usually adds to the resale value of a vehicle.</p>
				<br> <br>

				<img src="https://images.pexels.com/photos/4239035/pexels-photo-4239035.jpeg?auto=compress&cs=tinysrgb&w=400" class="rounded mx-auto d-block" alt="..."><br>
				<caption>Services </caption><br><br>

				<p style="font-size:20px;">Cleaning is the process of removing unwanted substances, such as dirt, infectious agents, and other impurities, from an object or environment. Cleaning occurs in many different contexts, and uses many different methods. Several occupations are devoted to cleaning</p>
				<br> <br>

				<div class="list-group">
					  <button type="button" class="list-group-item list-group-item-action active" aria-current="true">
					   <h5> CLEANING SERVICES </h5>
					  </button>
					  <button type="button" class="list-group-item list-group-item-action">
					  <h5>Interior maintainance</h5>
					  </button>
					  <button type="button" class="list-group-item list-group-item-action"><h5>Laptop and computer blower cleaning as well as reparing</h5>
					  </button>
					  <button type="button" class="list-group-item list-group-item-action"><h5>House / car vaccum cleaning</h5>
					  </button>
					  <button type="button" class="list-group-item list-group-item-action" ><h5>Pest cleaning services</h5>
					  </button>
				</div><br>




			</p>
			
	</center>

<!-- ANIMATED COUNTER CODE START -->
<link href= "https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" 
      integrity="sha384giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
   <style>
      .container{
         background-color: rgba(0, 0, 0, 0.2);
      }
      p{
      text-align: center;
      }
   </style>
<body onload="load()">
      <p>
      <div class="d-flex justify-content-center fs-1 fw-bold "><h4>Welcome To Phenomenal Infrastructure utility company (PIUC)</h4></div>
      <div class="d-flex justify-content-center fs-1 fw-bold "style="color: indigo;"> Counter</div>
      </p>
      <p>
      <div class="container" style="background-color: #993333;">
         <div class="row">
            <div class="col-sm">
               <p id='0101' class="fs-2 text-light">100</p>
               <p class="text-light">Site visits</p>
            </div>
            <div class="col-sm">
               <p id='0102' class="fs-2 text-light">50</p>
               <p class="text-light">Members signed</p>
         </div>
         <div class="col-sm">
            <p class="fs-2 text-light"><span id='0103'>5</span>%</p>
            <p class="text-light align-content-center">Average complain rate</p>
         </div>
      </div>
   </div>
   </p>
   <script>
      function animate(obj, initVal, lastVal, duration) {
         let startTime = null;

      //get the current timestamp and assign it to the currentTime variable
      let currentTime = Date.now();

      //pass the current timestamp to the step function
      const step = (currentTime ) => {

      //if the start time is null, assign the current time to startTime
      if (!startTime) {
         startTime = currentTime ;
      }

      //calculate the value to be used in calculating the number to be displayed
      const progress = Math.min((currentTime - startTime)/ duration, 1);

      //calculate what to be displayed using the value gotten above
      obj.innerHTML = Math.floor(progress * (lastVal - initVal) + initVal);

      //checking to make sure the counter does not exceed the last value (lastVal)
      if (progress < 1) {
         window.requestAnimationFrame(step);
      } else {
            window.cancelAnimationFrame(window.requestAnimationFrame(step));
         }
      };
      //start animating
         window.requestAnimationFrame(step);
      }
      let text1 = document.getElementById('0101');
      let text2 = document.getElementById('0102');
      let text3 = document.getElementById('0103');
      const load = () => {
         animate(text1, 0, 200, 7000);
         animate(text2, 0, 50, 7000);
         animate(text3, 100, 5, 7000);
      }
   </script>
</body>
<!-- ANIMATED COUNTER CODE END -->

		
</div>

</section>
</body>
<?php
			include 'footing.php';			
		?>
</html>