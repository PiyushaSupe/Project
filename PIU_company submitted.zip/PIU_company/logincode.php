<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
<style type="text/css">

	.error {

   background: #F2DEDE;

   color: #0c0101;

   padding: 10px;

   width: 95%;

   border-radius: 5px;

   margin: 20px auto;

   font-size: 30px;

}
	
</style>
<?php

	// require('dbconnect.php');

	// $user = $_POST['user'];
	// $pwd = $_POST['pwd'];

	
	// 	$sql = "Select * from signup where name = '$user' and password = '$pwd'";

	// 	$run1=mysqli_query($conn,$sql);

	// 	$res = mysqli_fetch_array($run1);

	// 	$count = mysqli_num_rows($run1);

	// 	if($count == 1)
	// 	{
	// 		//echo "<h1>Login Successfull !!</h1>";
	// 		header("Location: insidelogin.php");
	 
			 
	// 	}

	// 	else
	// 	echo "<h1>Invalid details: try again <br><br>OR<br> Please register yourself! </h1><br><br> <input type=\"button\" class = \"btn lg  btn-warning\" name=\"reg\" value=\"Register\" onclick=\"window.open('signupform.php')\">";

session_start(); 

require('dbconnect.php');

if (isset($_POST['user']) && isset($_POST['pwd'])) {

    function validate($data){

       $data = trim($data);

       $data = stripslashes($data);

       $data = htmlspecialchars($data);

       return $data;

    }

    $uname = validate($_POST['user']);

    $pass = validate($_POST['pwd']);

    if (empty($uname)) {

        header("Location: loginpage.php?error=User Name is required");

        exit();

    }else if(empty($pass)){

        header("Location: loginpage.php?error=Password is required");

        exit();

    }else{

        $sql = "SELECT * FROM signup WHERE username ='$uname' AND password='$pass'";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 1) {

            $row = mysqli_fetch_assoc($result);

            if ($row['username'] === $uname && $row['password'] === $pass) {

                echo "Logged in!";

                $_SESSION['username'] = $row['username'];

                $_SESSION['name'] = $row['name'];

                $_SESSION['id'] = $row['id'];

                header("Location: index.php");

                exit();

            }else{

                header("Location: loginpage.php?error=Incorect User name or password");

                exit();

            }

        }else{

            header("Location: loginpage.php?error=Incorect User name or password");

            exit();

        }

    }

}else{

    header("Location: loginpage.php");

    exit();

}
		
	

?>
