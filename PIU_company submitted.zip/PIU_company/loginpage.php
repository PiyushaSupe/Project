<title>Login page of PIUC</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- font awesome links -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" >
	<link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css">

			<!--bootstrap css links -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
			<!-- bootstrap js links -->
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
<body style="background:url('https://images.pexels.com/photos/370799/pexels-photo-370799.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1000'); background-size: cover; background-attachment: fixed;">
<form action="logincode.php" method="post">	
<div >	
<section class="vh-500" >
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-12 col-md-8 col-lg-6 col-xl-5">
        <div class="card shadow-2-strong" style="border-radius: 1rem;">
          <div class="card-body p-5 text-center">
          	<img src="piuclogo.jpg" width="300px " height="100px">

          	 <?php if (isset($_GET['error'])) { ?>

            <p class="error" name="error"><?php echo $_GET['error']; ?></p>

        <?php } ?>

            <h1 class="mb-5">Sign in</h1>

            <div class="form-outline mb-4">
            	<label class="form-label" for="username"><h4>Username </h4></label>
              <input type="text" id="username" name = "user" class="form-control form-control-lg" required />
              
            </div>

            <div class="form-outline mb-4">
            	<label class="form-label" for="pwd"><h4>Password</h4></label>
              <input type="password" name="pwd" id="pwd" class="form-control form-control-lg" required />
              
            </div>

            <!-- Checkbox -->
            <div class="form-check d-flex justify-content-start mb-4">
              <input class="form-check-input" type="checkbox" value="" id="form1Example3" />
              <label class="form-check-label" for="form1Example3"> Remember password </label>
            </div>

            <button class="btn btn-primary btn-lg btn-block" name="login" type="submit">Login</button>
            <button class="btn btn-warning btn-lg btn-block" onclick="window.open('signupform.php')">Register</button>


            <hr class="my-4">

            <button class="btn btn-lg btn-block btn-danger" onclick="window.open('index_piu_company.php')">Go to homepage</button> 

          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</div>
</form>
</body>