<!-- PIU_COMPANY_phenomenal picturesque infrastructure company -->
<?php 
		require_once('./php/component.php');
	    require_once('./php/CreateDb.php');

	    //create instance of CreateDb class
	$database = new CreateDb("Productdb","Producttb");


?>
<?php include('element.php'); ?>
<?php 
		include 'heading.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Homepage piu company</title>
	<!-- font awesome links -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" >
	<link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css">

			<!--bootstrap css links -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
			<!-- bootstrap js links -->
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>


    <style type="text/css">
    	.container-fluid{
    		background: url('https://images.pexels.com/photos/4391612/pexels-photo-4391612.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1');
    		background: url('https://images.pexels.com/photos/7078666/pexels-photo-7078666.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1000');

    		background-size: cover;
    		background-attachment: fixed;

    	}
    	footer{
    		width: 100%;
    	}
    	img{
    		
    	}
    	.glowing{
		    		/*text-shadow:
		  0 0 10px #fff700, 0 0 20px #fff700,
		  0 0 30px #fff700, 0 0 50px #fff700;*/

		  text-shadow:
		  0 0 10px white, 0 0 20px white,
		  0 0 30px white, 0 0 30px white;

		  font-style: italic;
		  font-family: lucida;
		  font-size: 50px;
		  font-weight: bolder;
		  background-color: ;
		  color: black;


		    	}
    </style>
</head>
<body>
	<div class="container-fluid">
		<br>
		<marquee><h4 style="color:white;"><span class="badge badge-secondary">New</span>&nbsp;&nbsp;Happy news for all dear customers: Now you can register your services and become and entrepreneur where we provide you a platform and get so many new perks like prioritized services just for you and instant and remarkable fixing services!!!</h4> </marquee>


		
		<center>
		<h1 class="glowing">Phenomenal Infrastructure Utility Company (PIUC) </h1>
		</center>

		<?php 
		include 'slides.php';
		div_space();
		?>

		<center>
		<h2 class="glowing">The following are the services precisely listed and available:  </h2>
		</center>


		<div class="row">
			
		<?php
			$result = $database->getData();
			while($row = mysqli_fetch_assoc($result)){
				homepgelement($row['product_name'],$row['product_price'],$row['product_image'], $row['id'],$row['description'],$row['companyname']);
			}
			div_space();
		
		?>
	
		</div>
		

		<?php 
		
		div_space();
		?>
	
</div>
</body>
<?php
	include 'footing.php';			
?>
</html>

