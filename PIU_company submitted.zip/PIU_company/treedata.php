<?php



require('dbconnect.php');

	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$mail = $_POST['mail'];
	$address1 = $_POST['address1'];
	$address2 = $_POST['address2'];
	$city = $_POST['city'];
	$state = $_POST['state'];
	$zip = $_POST['zip'];
	$number = $_POST['number'];
	$name = $_POST['name'];
	$purpose = $_POST['purpose'];
	$subtotal = $_POST['subtotal'];
	$total = $_POST['total'];


	$sql1 = "Insert into tree(
		fname,
		lname,
		mail,
		address1,
		address2,
		city,
		state,
		zip,
		number,
		name,
		purpose,
		subtotal,
		total)values(
	'$fname',
	'$lname',
	'$mail',
	'$address1',
	'$address2',
	'$city',
	'$state',
	'$zip',
	'$number',
	'$name',
	'$purpose',
	'$subtotal',
	'$total'
	);"; 


	$run=mysqli_query($conn,$sql1 );
	//echo "<script>window.location.replace = ('treesforgood.php')</script>";
	echo "<script>window.location.replace('treesforgood.php');
	window.alert('Congrats for a successful order!')</script>";
	
	
?>