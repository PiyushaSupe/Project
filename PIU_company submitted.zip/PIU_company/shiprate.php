<?php include 'heading.php'; ?>
<?php include 'element.php'; ?>

<head>
	<!-- font awesome links -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" >
	<link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css">

			<!--bootstrap css links -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
			<!-- bootstrap js links -->
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
</head>
<style type="text/css">
#ship{
	font-size: 20px;
	font-family: ;
	/*background: url('https://images.pexels.com/photos/414579/pexels-photo-414579.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1');*/
	opacity: ;
  background: black;

	background-size: cover;
	border: 3px solid indigo;
	margin: 30px 30px 30px 30px;
}	
/*#h2ofship{
	background-color: white;
	border-radius: 20px;
	padding: 20px 10px 20px 10px;
	margin: 0px 30px 0px 30px;
}*/

#h2ofship{
  font-size: 40px;
  color: #fff;
  text-align: center;
  color: black;
  font-family: georgia;
  background: floralwhite;
  padding: 20px 20px 20px 20px;
  /*animation: glow 1s ease-in-out infinite alternate;*/
  text-shadow:
      0 0 5px #fff700, 0 0 10px #fff700,
      0 0 20px #fff700, 0 0 40px #fff700;
}

/*@-webkit-keyframes glow {
  from {
    text-shadow: 0 0 10px #fff, 0 0 20px #fff, 0 0 30px #e60073, 0 0 40px #e60073, 0 0 50px #e60073, 0 0 60px #e60073, 0 0 70px #e60073;
  }
  
  to {
    text-shadow: 0 0 20px #fff, 0 0 30px #ff4da6, 0 0 40px #ff4da6, 0 0 50px #ff4da6, 0 0 60px #ff4da6, 0 0 70px #ff4da6, 0 0 80px #ff4da6;
  }
}*/

#imageofman{
	box-shadow: 10px 10px lightcyan;
  border-radius: 20px;
}
th{
	background: lightskyblue;
}
table{
	text-align: center;
}

</style>
<?php div_space();  ?>

<marquee><h3><span class="btn btn-danger">Please read </span>These rates may not be printed in your bill but can be charged on site services depending upon the companies terms and services</h3></marquee>
<section id = "ship">
<br> <br> <br>
	<center><h3 id="h2ofship"><i>Shipping Rates/ Rate of delivery of materials or parts to be changed</i> </h3><br> <br>
<img src="https://images.pexels.com/photos/7706383/pexels-photo-7706383.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"  width="500px" height="700px" id="imageofman" >
	</center>

	<br> <br>

	<table class="table  table-light table-hover">
  <thead>
    <tr>
      <th scope="col">Sr.</th>
      <th scope="col">Weight of materials</th>
      <th scope="col">Conditions or reasons why<br> (may differ due to other conditions as well) </th>
      <th scope="col">Prices of service</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>0.5 kg</td>
      <td>Depends upon the delicateness of the materials and transport charges </td>
      <td>&#8377;100</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>1 kg</td>
      <td>Depends upon the delicateness of the materials and transport charges</td>
      <td>&#8377;100</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>1.5 kg</td>
      <td>Depends upon the delicateness of the materials and transport charges</td>
      <td>&#8377;100</td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td>1.75 kg</td>
      <td>Depends upon the delicateness of the materials and transport charges</td>
      <td>&#8377;100</td>
    </tr>
    <tr>
      <th scope="row">5</th>
      <td>2 kg</td>
      <td>Depends upon the delicateness of the materials and transport charges</td>
      <td>&#8377;150</td>
    </tr>
    <tr>
      <th scope="row">6</th>
      <td>2.5 kg</td>
      <td>Depends upon the delicateness of the materials and transport charges</td>
      <td>&#8377;150</td>
    </tr>
    <tr>
      <th scope="row">7</th>
      <td>2.75 kg</td>
      <td>Depends upon the delicateness of the materials and transport charges</td>
      <td>&#8377;150</td>
    </tr>
    <tr>
      <th scope="row">8</th>
      <td>3 kg</td>
      <td>Depends upon the delicateness of the materials and transport charges</td>
      <td>&#8377;200</td>
    </tr>
    <tr>
      <th scope="row">9</th>
      <td>3.5 kg</td>
      <td>Depends upon the delicateness of the materials and transport charges</td>
      <td>&#8377;200</td>
    </tr>
    <tr>
      <th scope="row">10</th>
      <td>4 to 6 kg</td>
      <td>Depends upon the transport and delivery + repair charges</td>
      <td>&#8377;200</td>
    </tr>
    <tr>
      <th scope="row">11</th>
      <td>6 to 10 kg</td>
      <td>Depends upon the transport and delivery + repair charges</td>
      <td>&#8377;300</td>
    </tr>
    <tr>
      <th scope="row">12</th>
      <td>Over 10 kg</td>
      <td>Depends upon the transport and delivery + repair charges</td>
      <td>&#8377;500</td>
    </tr>
  </tbody>
</table>


	
<br> <br> <br>
</section>


<?php include 'footing.php'; ?>